﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlEditor.Core
{
    public enum LanguageEnum
    {
        //se-SV
        Swedish,
        //da-DK
        Danish,
        //en-US
        English,

        

    }
}
