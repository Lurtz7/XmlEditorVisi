﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlEditor.Core
{
    public enum TenantEnum
    {
        root,
        sop,
        PTK,
        Folksam,
    }
}
